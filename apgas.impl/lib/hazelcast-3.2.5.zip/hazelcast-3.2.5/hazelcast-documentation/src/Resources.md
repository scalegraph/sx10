
## Resources


-	Hazelcast source code can be found at [Github/Hazelcast](https://github.com/hazelcast/hazelcast).
-	Hazelcast API can be found at [Hazelcast.org](http://www.hazelcast.org/docs/latest/javadoc/).
-	More use cases and resources can be found at [Hazelcast.com](http://www.hazelcast.com).
-	Questions and discussions can be post in [Hazelcast mail group](https://groups.google.com/forum/#!forum/hazelcast).

<br> </br>





## Documentation

To see the documentation, click on the **Documentation** button located at the toolbar. Management Center manual will appear as a tab.


# Clients

There are currently three ways to connect to a running Hazelcast cluster:

- [Native Clients](#native-clients)

-	[Memcache Clients](#memcache-client)

-	[REST Client](#rest-client)

